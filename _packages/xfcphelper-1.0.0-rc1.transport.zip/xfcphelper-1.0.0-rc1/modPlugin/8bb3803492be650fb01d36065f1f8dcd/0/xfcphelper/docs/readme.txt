--------------------
xFCPHelper
--------------------

First Released: December 29th, 2012
Author: Jérôme Perrin <hello@jeromeperrin.com>
License: GNU GPLv2 (or later at your option)

This component is a plugin for MODX 2.2+. It extends xFCP by adding support for the following Resource tree's context menu actions: publish, unpublish, delete, undelete.

How to use: Make sure xFCP is installed. Enjoy.

Bugs & Feature requests: https://github.com/yogoo/xFCPHelper/issues

Install via MODX Package Management or download from https://github.com/yogoo/xFCPHelper
